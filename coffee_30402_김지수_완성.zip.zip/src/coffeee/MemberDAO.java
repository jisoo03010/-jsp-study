package coffeee;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class MemberDAO {
	private Connection conn = null;
	private PreparedStatement stmt = null;
	private ResultSet rs = null;
	
	
	
	
	public List<MemberVo> getMenuList() {

		List<MemberVo> menuList = null;
		try {
			conn = JDBCConnection.getConnection();
			String sql = "select * from tbl_salelist_01";
			stmt = conn.prepareStatement(sql);
			
			rs = stmt.executeQuery();
			
			menuList = new ArrayList<MemberVo>();
			
			while(rs.next()) {
				MemberVo menu = new MemberVo();
				menu.setSaleno(rs.getInt("saleno"));
				menu.setPcode(rs.getString("pcode"));
				menu.setSaledate(rs.getDate("saledate"));
				menu.setScode(rs.getString("scode"));
				menu.setAmount(rs.getInt("amount"));
				
				menuList.add(menu);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCConnection.close(rs, stmt, conn);
		}
		
		return menuList;
	}
	
	//��ǰ�� �Ǹž�
	public List<MemberVo> getSalseProduct() {

		List<MemberVo> salesList = null;
		try {
			conn = JDBCConnection.getConnection();
			String sql = "SELECT ts.pcode, tp.name, SUM(tp.cost * ts.amount) hap FROM tbl_product_01 tp JOIN tbl_salelist_01 ts on tp.PCODE = ts.PCODE GROUP BY ts.pcode, tp.name ORDER BY ts.pcode";
			stmt = conn.prepareStatement(sql);
			
			rs = stmt.executeQuery();
			
			salesList = new ArrayList<MemberVo>();
			
			while(rs.next()) {
				MemberVo sales = new MemberVo();
				sales.setPcode(rs.getString("pcode"));
				sales.setName(rs.getString("name"));
				sales.setCost(rs.getInt("hap"));
				System.out.println(rs.getString("pcode"));
				salesList.add(sales);
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			JDBCConnection.close(rs, stmt, conn);
		}
		
		return salesList;
	}
	
	//���庰 �Ǹž�
		public List<MemberVo> getMarketProduct() {

			List<MemberVo> marketList = null;
			try {
				conn = JDBCConnection.getConnection();
				String sql = "SELECT sp.scode scode, sp.sname sname, SUM(pd.cost * sl.amount) cost FROM tbl_shop_01 sp , tbl_product_01 pd, tbl_salelist_01 sl WHERE pd.pcode = sl.pcode and sp.scode = sl.scode GROUP BY sp.scode, sp.sname ";
				stmt = conn.prepareStatement(sql);
				
				rs = stmt.executeQuery();
				
				marketList = new ArrayList<MemberVo>();
				
				while(rs.next()) {
					MemberVo market = new MemberVo();
					market.setScode(rs.getString("scode"));		
					market.setSname(rs.getString("sname"));
					market.setCost(rs.getInt("cost"));
					System.out.println("sname : " + rs.getString("sname"));
					marketList.add(market);
				}
				
			} catch (Exception e) {
				e.printStackTrace();
			} finally {
				JDBCConnection.close(rs, stmt, conn);
			}
			
			return marketList;
		}
}
