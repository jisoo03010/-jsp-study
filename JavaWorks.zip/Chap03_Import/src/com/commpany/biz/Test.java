package com.commpany.biz;

import com.commpny.biz.A07_Jumsu;

public class Test {
	public static void main(String[] args) {
		//A07_Jumsu nolbu = new A07_Jumsu("놀부", 100, 50);
	}
}
