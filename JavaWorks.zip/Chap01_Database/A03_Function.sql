--문자열 함수

--문자열을 받아 적절한 처리를 하는 함수. 함수명(값) 형태로 사용한다.
--표시는 해당 함수가 실행된 결과값을 출력한다

--대문자, 소문자, 단어의 첫 글자만 대문자를 변경한다.
--upper => 대문자
--lower =>소문자
select upper(first_name), lower(first_name)
from employees

--함수는 함수 내부에 함수를 호출 사용가능 upper(lower(value))형태
select first_name || ' ' ||last_name as name
from employees

select lower( first_name || ' ' ||last_name )as name
from employees

--initcap => 단어의 첫 글자만 대문자로 변경
select initcap(upper( first_name || ' ' ||last_name )) as name
from employees

--이름의 첫 3글자만 닉네임 형태로 표시하고자 한다.
--오라클은 시작이 0이 아닌 1부터 시작. JDBC에서도 마찬가지
--substr(value, 시작번호, 몇글자를 추출할 것인가)

select first_name, substr(first_name,1,3)
from EMPLOYEES

select first_name,upper(substr(first_name,1,3)) 
from EMPLOYEES

--입사연도가 05, 06년에 입사한 직원은?

select  hire_date, substr(hire_date,1,2)
from employees
where substr(hire_date,1,2) in('05','06')


--첫 이름이 5글자 이상인직원은?
select first_name, length(first_name) 
from employees
where length(first_name) >= 5

--첫 이름을 10자 확보하고 남는 곳은 *로 채우자
--lpad => left pad
--rpad => right pad
select first_name, lpad(first_name,10,'*') 
from employees

--첫 이름에 공백이 포함되어 있으면 모두 삭제하고 순수한 문자만 출력하자
--ltrim => left trim
--rtrim => right trim 오른쪽 값을지우는거
--trim => left, right모두 trim
select first_name, ltrim(first_name) ,rtrim(first_name)
from employees

--기본이 공백문자이고 지울 문자를 지정하면 그 문자는 삭제된다
select first_name,
	ltrim(lpad(first_name,10,'*'),'*'),
	rtrim(rpad(first_name,10,'*'),'*'),
	rtrim(first_name,'n')
from employees
where first_name like '%n'

--변경 replace - 그룹매치
--변경 translate -> 각 글자 매치
select first_name, replace(first_name, 'A', 'X')
from EMPLOYEES
where first_name like 'A%'

--두 글자가 매칭되는 항목만 변경
select first_name, replace(first_name, 'Am', 'Xx')
from EMPLOYEES
where first_name like 'A%'

--translate. 한글자 한 글씩 매칭해서 변경한다
select first_name, translate(first_name, 'A', 'X')
from EMPLOYEES
where first_name like 'A%'

select first_name, translate(first_name, 'Aa', 'Xx')
from EMPLOYEES

select phone_number, translate(phone_number, '0123456789', '영일이삼사오육칠팔구')
from EMPLOYEES


--위치
--instr(value, 찾고자하는 문자, 시작위치, 몇번째를 찾을 것인가)
select first_name, instr(first_name, 'a' ,1,1)
from EMPLOYEES

--이름에 a가 1번 포함된 직원은?
select EMPLOYEE_id, first_name, salary,hire_date, DEPARTMENT_id
from EMPLOYEES
where first_name like '%a%'

--a가 두번 포함되도 검색된다.
select EMPLOYEE_id, first_name, salary,hire_date, DEPARTMENT_id
from EMPLOYEES
where instr(first_name,'a', 1,2)=0

--a가 두번들어간 직원
select EMPLOYEE_id, first_name, salary,hire_date, DEPARTMENT_id
from EMPLOYEES
where instr(first_name,'a', 1,2) > 0

--숫자 함수
--필드에서 연산도 가능
select 10 - 2, 10 + 2, 10 * 2, 10 / 2, mod(10,3) --mod(10,3) => 나머지 값
from EMPLOYEES

--오라클에서 제공하는  dumy table. row가 딱 1줄있다. 값은 의미없다
--dual을 사용하므로써 한줄만 나오게 한다.
select * from dual;
select 10 - 2, 10 + 2, 10 * 2, 10 / 2, mod(10,3) 
from dual;

--floor => 소수를 정수로 만들고, 무조건 버림 : 정수 리턴
--ceil(value) => 소수점을 무조건 올림: 정수리턴
--round(value) => 반올림 : 정수리턴
select floor(10.9), ceil(10.3),round(10.4),round(10.345)
from dual;

--**round만 소수점 어느 위치에서 반올림할 것을 지정할 수 있음
select round(10.445 , 2), round(10.495,2)
from dual;

--*trunc 소수점 지정에서 무조건 버림
select trunc(10.545), trunc(10.445, 2), trunc(10.495, 2)
from dual;

select DEPARTMENT_id, max(salary), sum(salary), trunc(avg(salary),2), count(*)
from EMPLOYEES;
group by DEPARTMENT_id
order by DEPARTMENT_id


--날짜 함수
-- + ,- 는  일자 기준으로 이루어 진다.
--sysdate라는 키워드는 오늘 날짜를 나타낸다
select sysdate from dual;
select sysdate + 1, sysdate -1 from dual; -- sysdate + 1 => 하루앞 -1=> 전날


select sysdate + 100
from dual

--월 단위로만 함수가 존재한다.
--6달 후의일자는
select sysdate, add_months(sysdate, 6)
from dual

--올해 크리스마스까지 몇칠 남았을까?
select sysdate, months_between(sysdate, '2021-12-25')
from dual;

select sysdate, months_between( '2021-12-25', sysdate)
from dual;

--이번달 며칠까지 있나?
select sysdate, last_day(sysdate)
from dual;

--이름이 'A'로 시작되는사람의 입사 10주년이 되는 날은?
--alias에 숫자 또는 빈 공백이 포함 되면 "(더블)로 지정한다.
select first_name, hire_date, add_months(hire_date, 10*12) as "10주년"
from EMPLOYEES
where first_name like 'A%'

--이름이 'A'로 시작되는 사람의 입사일, 연령대(입사일을 생일로) 조회
select first_name, hire_date, 
		trunc(months_between(sysdate, hire_date) /12, -1 )|| '대' as "연령대"
from EMPLOYEES
where first_name like 'A%';

--이름이 'A'로 시작되는 사람의 입사일, 나이, 월조회
select first_name, hire_date, 
		trunc(months_between(sysdate, hire_date) /12)|| '세',
		trunc(mod(months_between(sysdate, hire_date), 12) ) || '개월' as "개월"
from EMPLOYEES
where first_name like 'A%';



------*************변환함수
--to_char()

--오늘의 날짜를 년/월/일/시간:분:초 형태로 표시
select sysdate, to_char(sysdate, 'yyyy/mm/dd day am hh:mi:ss')
from dual;

--문자를 날짜 형태로 변경
select to_date('20211225', 'yyyy-mm-dd')
from dual;

--연도만 출력
select to_char(sysdate, 'yyyy')"년",
		to_char(sysdate,'mm')"월",
		to_char(sysdate,'dd')"요일"
		

from dual;
--올해 크리스마스는 무슨요일일까?
select to_char(to_date('2021-12-25', 'yyyy-mm-dd'),'day')
from dual;

--12월에 입사한 직원은?
select first_name, hire_date
from EMPLOYEES
where to_char(hire_date, 'mm') = '12'

--to_number
-- 9는 자리수가 없으면 알아서 생략됨
-- 0은 자리수가 없으면 0으로 채움
-- ,와 .은 지정한 자리수 별로 자동으로 채워짐


select first_name, salary,
		to_number('123,456', '999999'),
		to_number('123,456', '000000')
from EMPLOYEES
where department_id in(30,60,90)

--*****NULL 처리함수
-- 값이 null이면 모든 연산은 결과값이 null이다.
--commission_pct는 타입이 number(2,2)이므로 정수는 대입하지 못한다.
select first_name, commission_pct, commission_pct +0.1
from EMPLOYEES
where department_id in(30, 80)

--null처리 함수인 nvl로 처리
--nvl(필드명, 필드가 null이면 대체할 값)
select first_name, commission_pct,
		nvl(commission_pct , 0.1)
from EMPLOYEES
where department_id in(30, 80)

--insert 구문
insert into tableName(id,name)
	values(null, 'Nolbu')
--게시물이 1개도 없는 경우 id는 null을 가지고 있다.
--따라서 1을 더해도 결과는 null. null이 안되게 null을 0으로 치환 한 후 1을 더한다.
select nvl(max(id),0) + 1 from tableName;


insert into tableName(id,name)
	values(select nvl(max(id),0) + 1 from tableName), 'Nolbu')


--nvl2 => null인 경우와 null이 아닌 경우를 구분해서 값을 변경하고자 할 경우에 사용한다.
--nvl2(컬럼명, null이 아니면 대입할 값, null이면 대입할 값)
--30, 80번 부서의 commission_pct에 0.1씩 더하자
	
select first_name, commission_pct,
		nvl2(commission_pct ,commission_pct + 0.1, 0.1)
from EMPLOYEES
where department_id in(30, 80)
	
--조건에 따라 값을 변경
--decode(필드명 ,
--	필드명과 비교할 값, 변경값, 
--	필드명과 비교할 값, 변경값, 
--	필드명과 비교할 값, 변경값, 
--	...,
--	위와 매칭되지 않는 경우 변경할 값)

--연산이 =(같다)인경우만 사용
select first_name, department_id,
	decode(department_id,
			30, 'A팀',
			40, 'B팀',
			60, 'C팀',
			80, 'D팀',
			90, 'E팀',
			'팀 없음'     --else
	) as Team
from EMPLOYEES
where DEPARTMENT_ID in(30,40,60,80,90,100,110)
	
--case 구문. 조건을 달 수 있어 편리하다.decode보다 직관적이다
select first_name, department_id,
	case 
		when salary >= 20000 then 'A팀'
		when salary >= 15000 then 'B팀'
		when salary >= 10000 then 'C팀'
		else '팀 없음'
	end
from EMPLOYEES
where DEPARTMENT_ID in(30,40,60,80,90,100,110)
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	