--그룹 함수. (결과가 한 줄에 표시된다)

--한달에 월급은총 얼마가 나갈까?  => 월급을 다 더하면 됨
select sum(salary)
from employees

--first_name이 다중행이고, sum(salary)가 단일행이여서 같이 출력이 불가하다 => error
select first_name , sum(salary) 
from employees


--직원의 월 평균
select avg(salary) 
from employees

--월급을 제일 많이 받는 직원의 금액
select max(salary) 
from employees

--월급을 제일 적게 받는 직원의 금액
select min(salary) 
from employees

--직원 총수
select count(salary) 
from employees

select max(salary), min(salary), avg(salary), count(salary) , sum(salary)
from employees

--각 부서별로 월급의 총 합을 구하고자한다. 

select sum(salary)
from employees
group by DEPARTMENT_ID;   --department_id별로 그룹을 잡아 합계를 출력해라

--12개의 값은 각 department_id 별로 출력이 되서 결과가 12개
--따라서  group by에 참여한 컬럼은 select문에 참여할 수 있다.
select DEPARTMENT_ID, sum(salary)
from employees
group by DEPARTMENT_ID;

--에러 출력
select first_name, DEPARTMENT_ID, sum(salary)
from employees
group by DEPARTMENT_ID;

--결과값이 출력됨
--first_name과 department_id가 같은 직원을 하나의 그룹으로 묶는다.
select first_name, DEPARTMENT_ID, sum(salary)
from employees
group by DEPARTMENT_ID, first_name;

--각 부서별 월급 합계, 최고월급, 최저월급, 평균, 인원수.
--부서번호로 내림차순 정렬
--null은 제외

--from의 테이블에서 한 줄 읽어서 where절에서 걸러내고 그룹을 하고... 
--row를 검색해서 걸러냄
--order by =>정렬

select DEPARTMENT_ID, sum(salary), max(salary), min(salary),avg(salary), count(salary)
from employees
where department_id is not null --where절에서 걸러낸다
group by DEPARTMENT_ID
order by department_id desc


--where => row단위로 검색을 해서 걸러낸다.
--having => group by와 같이사용해야 한다. 독립적으로 사용 못함
--having은 group by의 결과가 만들어진 가상의 테이블에서 검색해서 걸러낸다.
select DEPARTMENT_ID, sum(salary), max(salary), min(salary),avg(salary), count(salary)
from employees
where department_id is not null --where절에서 걸러낸다
group by DEPARTMENT_ID
having department_id is not null
order by department_id desc

--월급의 총 합이 50000 이상인 부서
select DEPARTMENT_ID, sum(salary), max(salary), min(salary),avg(salary), count(salary)
from employees
group by DEPARTMENT_ID
having sum(salary) >= 50000   --그룹의 결과에서 검색해 걸러낼 목적 --월급의 총합이 50000보다 적으면 다 잘라냄
order by department_id desc

--count는 주의해서 사용해야 한다.
--count는  null을 제외하고 카운트해야한다****
--* (별)은 모든것을 의미한다.
--count = 중복을 제거
select count(*) ,count(salary), count(commission_pct)
from EMPLOYEES

--각 카운트되는 수를 출력한다.
select DEPARTMENT_ID, sum(salary), max(salary), min(salary),avg(salary), count(*)
from employees
group by DEPARTMENT_ID		
having sum(salary) >= 50000   --그룹의 결과에서 검색해 걸러낼 목적
order by department_id desc --내림차순

--직원수가 1명인 부서는 제외하자
select DEPARTMENT_ID, sum(salary), max(salary), min(salary),avg(salary), count(*)
from employees
group by DEPARTMENT_ID		
having count(*) > 1   --그룹의 결과에서 검색해 걸러낼 목적
order by department_id desc

--급여가 7000이상인 부서
--as => ?
select DEPARTMENT_ID, 
		sum(salary)as sum, 		--jdbc에서는 Alias로 참조해서 출력
		max(salary)as max, 		
		min(salary) min,
		avg(salary) avg, 
		count(*) cnt
from employees
group by DEPARTMENT_ID		
having avg(salary) > 7000   --그룹의 결과에서 검색해 걸러낼 목적
order by department_id desc




































