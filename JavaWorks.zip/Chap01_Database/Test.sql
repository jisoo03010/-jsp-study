--문제 1) 급료가 12000 이상인 사람의 첫이름, 마지막 이름, 이메일, 급료 표시
--표시는 첫이름 - 마지막 이름(이메일) : 급료
select first_name|| '-' ||last_name||'('||email||'):'|| salary
from EMPLOYEES where salary >= 12000

--문제 2) 첫 이름이 Lex, Den, John인 사람의 첫이름, 마지막이름, 급료 출력
select first_name, last_name,salary
from EMPLOYEES where first_name in('Lex','Den','John')

--문제 3) DEPARTMENT_ID가 50인 직원중에서 봉급이 5000 이상이거나 MANAGER_ID가 120인
--직원의 첫이름, 마지막이름, 봉급 조회.
select first_name, last_name,salary,DEPARTMENT_ID,MANAGER_ID
from EMPLOYEES 
where  DEPARTMENT_ID =50 and (salary >=5000 or MANAGER_ID =120)

--문제4) DEPARTMENT_ID와 MANAGER_ID를 더한 결과가 200인 직원만 나오도록 출력.
--첫, 마지막 이름은 공백을 두고 합치고 별명은 "이름"으로, 합계는 "합계"라는 이름으로 표시

select first_name||' '|| last_name as "이름",salary,DEPARTMENT_ID + MANAGER_ID as "합계"
from EMPLOYEES where DEPARTMENT_ID + MANAGER_ID >=200


--문제 1) 이름이 'A'로 시작되는 사람들의 입사 30주기가 되는 날
select first_name, last_name, hire_date, add_months(hire_date, 30 *12)
from EMPLOYEES where first_name like 'A%'
--문제2) MANAGER_ID가 100번인 사람들의 이름과 입사일, 연령대(입사일을 생일이라 하고) 조회
select first_name, hire_date,trunc(months_between(sysdate,hire_date)/12,-1) ||'대' 연령대, MANAGER_ID
from EMPLOYEES where MANAGER_ID = 100


--문제 1) 12월에 입사한 사원의 이름, 입사일 조회
select first_name|| ' ' ||last_name, hire_date
from EMPLOYEES where to_char(hire_date, 'mon') = '12월';

--문제 2) 월요일 입사한 사원 조회
select first_name, hire_date
from EMPLOYEES where to_char(hire_date, 'd') = 2;














