-- 주석. 여기서는 세미콜론 안찍어도 동작한다.
-- 실행은 쿼리 선택후 오른쪽 마우스 클릭 execute select text 선택 --alt + x
select * from EMPLOYEES

--:::기본 자료형:::ㄴ
--number(4,0) 자리수 4자리 중 정수로4자리 소수점으로는 0
--number(2,2) 자리수 2자리 소수점으로 2자리 사용
--varchar2(10)  문자로 최대 10자 입력가능, 한글은 5자
--varchar2는 가변 문자열로 : 글자를 2자만 입력하면 2자리 용량만 차지
--char(10) 고정자리수 : 1자를 입력해도 10자의 용량은 유지
--date 날짜형. 입력시 지정된 포멧을 지켜야 한다. 2021-05-25, 2021/05/25 두가지만 가능

--제약조건
--NOT NULL => 입력할 때 값을 생략할 수 없음, (반드시 값을 넣어야함!!)
--PRIMARY KEY(PK)=> 유일한 값 (UNIQU)를 가져야 하며 값을 생략할 수 없다(NOT NULL)
--FORGIN KEY(FK) => 다른 테이블의 PK를 참좌는 값을 입력


-- 모든 Row를 출력
--출력 명령이 select 
--어느 파일에서 from
--실행은 항상  from절에서 시작한다.
-- * => 모든 컬럼을 의미
--명령줄에서 대소문자 구분하지 않음
--사원정보
select *
from EMPLOYEES

--부서 정보
select * from DEPARTMENTS
--부서의 위치 정보
select * from LOCATIONS
--한번에 묶어서 출력 - 조인
select * from EMPLOYEES, DEPARTMENTS, LOCATIONS


--DQL 
--전체 컬럼 모두 출력
select * from EMPLOYEES

--필요한 컬럼만 추려서 출력
select employee_id, first_name, salary, hire_date
from EMPLOYEES

--이름을 별도로 출력
select employee_id, first_name, last_name,salary, hire_date
from EMPLOYEES

--이름을 이어서 하나의 컬럼으로 출력 => || (붙여서의 의미)
select employee_id, first_name || last_name,salary, hire_date
from EMPLOYEES

--컬럼은 임의로 만들수도 있음, DB에서는 문자열은 ' (싱글)로 묶는다
--만든 컬럼은 테이블의 row수 만큼 출력된다.
select employee_id, '이름', first_name || last_name,salary, hire_date
from EMPLOYEES

--위 두개를 응용하면
select employee_id, first_name || ' ' || last_name,salary, hire_date
from EMPLOYEES

--Row를 걸러내자 - WHERE정을 이용한다.
--where 절은 비교를 통해 매칭되는 열만 추려 가상의 테이블을 만들고 그를 출력한다.

--30,60,90부서의직원만 출력
select 
from employees
where department_id =30 or department_id = 60 or department_id = 90

--or는 in으로 대체 가능
--테이블 작성시 제약조건을 달 경우도 IN을 사용한다.
select *
from employees
where department_id IN(30,60,90) -- department_id에 30,60,90번 부서가 안에 있니? 

--30번 부서와 60번 부서의 직원은?
select *
from employees
where department_id =30 or department_id = 60

--50번 부서 직원중 월급을 5000이상 받는 직원
select *
from employees
where department_id =50 and salary >= 5000

--월급이 5000d 이상 10000 이하인직원?
select *
from employees
where salary>=5000 and salary<=10000

--하나의 컬럼에서 and 연결은 between ~ and ~ 로 변경 가능
select *
from employees
where salary between 5000 and 10000 --5000과 10000포함

--이름이 'E'에서'M'사이의 직원
select *
from employees
where first_name between 'E' and 'm';

--입사일이 2005-01-01인 직원
select *
from employees
where hire_date between '2005-01-01' and '2005-12-31';
--2007-01-01 이후에 입사한 직원	(내부적으로 캐스팅 발생, 뒤에 변환함수에서 함)
select *
from employees
where hire_date> '2007-01-01';

--NULL은 조심해야한다. 조건문으로 판단하지 않고 not null, is not null 을 사용한다.
--commission이없는 직원(null인 직원)
select *
from employees
where commission_pct  = null; --에러는 없지만 결과가 나오지  않는다

select *
from employees
where commission_pct is null; 

select *
from employees
where commission_pct is not null; 

--ROW와 컬럼을 같이 걸러서 표시
select employee_id, first_name || ' ' || last_name, salary , hire_date, department_id
from employees
where commission_pct IS NOT NULL; 

--컬럼 이름을 변경해서 표시
--"컬럼면 AS alias" 또는 "컬럼명 alias" as 생략 가능
select EMPLOYEE_ID as emp_id,
		first_name || ' ' || last_name as name, 
		salary , hire_date, department_id dept_id
from employees
where commission_pct IS NOT NULL;


--검색 등에서 많이사용
--한 문잘를 나타냄 => _ (언더바 1개)
--어떤 값이든 허용 => %
--like와 함께 사용한다.

--사원중에 이름이 3글자인 직원
select employee_id, first_name, salary, hire_date, department_id
from employees
where first_name like '___'; 

--첫 글자가 'p'로 시작되면서 전체 글자가 3글자인 직원
select employee_id, first_name, salary, hire_date, department_id
from employees
where first_name like 'p___';

--첫 글자가 't'로 끝나면서 전체 글자가 3글자인 직원
select employee_id, first_name, salary, hire_date, department_id
from employees
where first_name like '___t'; 

--이름이 'A'인 직원, 값은 대소문자 구분
select employee_id, first_name, salary, hire_date, department_id
from employees
where first_name like 'A';  --결과없음

--이름이 'A'로 시작하는 직원
select employee_id, first_name, salary, hire_date, department_id
from employees
where first_name like 'A%'; --% 뒤가 어떤 값이 와도 상관없이 모두 포함

--이름이 마지막ㅇ 'a'로 끝나는 직원.
select employee_id, first_name, salary, hire_date, department_id
from employees
where first_name like '%a';

--이름이에 'a'가 포함된 직원.
select employee_id, first_name, salary, hire_date, department_id
from employees
where first_name like '%a%';

--이름중에 두번쨰 글자가 a로 시작되는 직원?
select employee_id, first_name, salary, hire_date, department_id
from employees
where first_name like '_a%';

--정렬 - order by 컬럼명 desc, asc
--원하는 순서대로 출력문을 정렬한다.

select employee_id, first_name, salary, hire_date, department_id
from employees
where department_id in(30,60,90)

--위의 결과를 월급순으로 정렬
select employee_id, first_name, salary, hire_date, department_id
from employees
where department_id in(30, 60, 90)
order by salary asc -- asc(오름차순)는 기본 정렬이라 생략이 가능하다

--위의 결과를 월급순으로 정렬
select employee_id, first_name, salary, hire_date, department_id
from employees
where department_id in(30, 60, 90)
order by salary desc -- 내림차순, desc는 생략 불가

--정렬은 다중 컬럼도 가능
--부서별로 월급을 가장 만이 받는 직원순으로 정렬하세요
--부서는 오름차순, 월급은 내림차순으로 정렬



select employee_id, first_name, salary, hire_date, department_id
from employees
where department_id in(30, 60, 90)
order by department_id asc, salary desc




----------------------------
------------------------------
------------------------
-------------------------
---------------------이해 완료!!!






