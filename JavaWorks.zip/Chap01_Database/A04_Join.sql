--Join
--오라클은 조인을 독자적인 방식으로 이용 ANSI(표준조인)도 지원함
--Join => 한개 이상의 테이블을 하나의 테이블로 묶는 작업
--from 절에서 사용할 테이블을 나열하기만 하면 된다.

--EMPLOYEES rows * DEPARTMENTS rows 만큼의 결과가 출력된다.
--이클립스는 최대 출력 개수가 500개 이다.
select *
from EMPLOYEES, DEPARTMENTS

--equals 조인
select *
from EMPLOYEES, DEPARTMENTS
where EMPLOYEES.DEPARTMENT_id = DEPARTMENTS.DEPARTMENT_ID 

--원하는 컬럼만 출력하자
--중복되는 이름이 있는 컬럼은 어느 테이블에서 출려갈 것인가를 앞에 기술해야한다.

--쿼리는 from절에서 시작하므로from 절의테이블에 Alias를붙이면
--전체 쿼리에서 alias를 사용할 수 있다.
--EMPLOYEES는 e로 치환, DEPARTMENTS는 d로 치환

--outer join
--이퀄 조인으로 출력된결과에서 where 절에 의해 해당되지 않은  row를 출력하는기능
--where 절에 의해 해당되지 않은 row를 출력하고자 하는 테이블의 반대쪽에(+) 를 붙인다.

--부서 번호가 없어 where 구문에 대칭되지 않은 직원도 표시하고자 한다.
select EMPLOYEE_id,first_name, salary, job_id,
		e.manager_id as "보스",
		e.DEPARTMENT_id,department_name,
		d.manager_id as "부서 담당자"
from EMPLOYEES e, DEPARTMENTS d
where e.DEPARTMENT_id = d.DEPARTMENT_ID(+)
order by employee_id

--부서에 직원이 1명도 없는 부서도 표시하고자 한다.
select EMPLOYEE_id,first_name, salary, job_id,
		e.manager_id as "보스",
		e.DEPARTMENT_id,department_name,
		d.manager_id as "부서 담당자"
from EMPLOYEES e, DEPARTMENTS d
where e.DEPARTMENT_id(+) = d.DEPARTMENT_ID
order by employee_id

--각 부서의 이름은 물론 주소까지 출력하고자 한다.
select * from EMPLOYEES
select * from DEPARTMENTS
select * from LOCATIONS

select employee_id, first_name, e.manager_id, e.department_id,
		d.department_name, d.location_id,
		loc.street_address, loc.city
from EMPLOYEES e, DEPARTMENTS d, LOCATIONS loc
where e.department_id = d.department_id
		and d.location_id = loc.location_id

		
--self join

select * 
from employees e, employees m
where e.manager_id = m.employee_id
order by e.employee_id
		
select e.employee_id, e.first_name, e.salary, e.hire_date, e.department_id,
		m.employee_id, m.first_name, m.salary, m.hire_date
from employees e, employees m
where e.manager_id = m.employee_id
order by e.employee_id


--ANSI Join
--모든 SQL에서 공통적으로 사용할 수 있는 표준 조인 방식을 의미한다.
--따라서어떤 SQL도 이 방법을 통해 조인을 실행할 수 있다.

--NATURAL Join
--테이블에 같은 이름의 컬럼을 비교해서 자동 조인이 이루어진다
--manager_id와 department_id 가 각테이블에 있으므로
--manager_id와 department_id가 같은 row만 출력된다

--where e.manager_id = d.manager_id and
--e.department_id = d.department_id 의 결과가 출력된다.
select employee_id, first_name, salary,department_id, department_name
from employees e natural join departments d
		

--equals 조인
--컬럼의 별칭은 붙여도 된다
--using()의 ()의 컬럼이 = 조건의 대상이되는 컬럼이다.
select employee_id, first_name, salary,department_id, department_name
from employees e join departments d using(department_id)

--natural join과 동일함
select employee_id, first_name, salary,department_id, department_name
from employees e join departments d using(department_id , manager_id)
		
		
--이 방식을 더 많이 사용
--중복되는 컬럼은 오라클처럼 어느 테이블에서 출력할 것인가를 기술해야한다.
select employee_id, first_name, salary,d.department_id, department_name
from employees e join departments d on(e.department_id = d.manager_id)		
order by employee_id
		
--outer join(외부 조이)
--on절에 조건에 만족하지 않아 출력되지 않은 row를 표시하고 할 경우 사용
--employee에 표시되지 않은 row도 출력
select e.employee_id, first_name, salary,d.department_id, department_name
from employees e right outer join departments d on(e.department_id = d.manager_id)		
order by employee_id

		
--oracle에서는 양쪽 모두 조건에 만족하는 컬럼을 출력하는 full join은 지원하지 않는다
--ANSI(표준)조인은 지원한다
		
select e.employee_id, first_name, salary,d.department_id, department_name
from employees e full outer join departments d on(e.department_id = d.manager_id)		
order by employee_id
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		