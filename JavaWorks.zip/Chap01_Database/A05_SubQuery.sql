--쿼리를 먼저 실행해 봐야다음 쿼리를 실행할 수 있는 경우에  사용한다.

--단일행 서브쿼리 ? 

--()로 묶어야 한다.
--비교 대상이 같은 타입과 같은 개수 이어야 한다.
--결과 값이 한 줄에 한 개의 값만 가지고 있는 경우

--Adam보다 월급을 출력하여라
select salary
from EMPLOYEES where first_name = 'Adam'

--Adam보다 월급을 많이 받는 직원을 출력하여라
select salary
from EMPLOYEES 
where salary >= (select salary from EMPLOYEES where first_name = 'Adam')
--select salary from EMPLOYEES where first_name = 'Adam'를 괄호로 묶는 이유? 먼저 실행하라는 뜻

--직원 평균 급여보다 많이 받는 직원?
select *
from EMPLOYEES 
where salary >= (select avg(salary) from EMPLOYEES)

--아담보다 입사일이 빠른 직원
select *
from EMPLOYEES 
where hire_date <= (select hire_date from EMPLOYEES where first_name = 'Adam')

--80번 부서의 평균 연봉보다 많이 받는 직원
select *
from EMPLOYEES 
where salary >= (select avg(salary) from EMPLOYEES where department =80)

--error. 비교할 대상의 값이 두개여서 안됨
select *
from EMPLOYEES 
where salary <= (select min(salary) ,max(salary)from EMPLOYEES where department =80)

--error. 서브쿼리의 비교 대상이 3줄이다.(다중행 서브쿼리는 가능)
select *
from EMPLOYEES 
where salary <= (select salary from EMPLOYEES where first_name = 'John')

select *
from EMPLOYEES 
where salary <= (select salary from EMPLOYEES where first_name = 'John' and department_id =80)

select * from EMPLOYEES
where first_name ='John'

--다중행 서브쿼리
--결과가 여러줄로 표시된다.
--따라서 = (같다)를 사용하지 못함. 대신IN, ANY, ALL등을 사용한다.
salary = 10000 or salary = 15000 or salary = 20000
select *
from EMPLOYEES 
where salary in(select salary from employees where first_name = 'John')

--각 부서에서 월급을 가장 많이 받는 직원
--1.부서별로 최대 월급을 구해야 한다.
--2. 1에서 구한 값과 직원의 부서번호를 비교해서 같은 사람중 1에서 구한 부서의 최대 월급과 같은 직원의 사번, 이름, 월급, 입사일을 출력

--부서별로 나오는게 아니라 테이블에서 최대 월급을 받느 직원 1명만 출력
select max(salary)
from EMPLOYEES 


select max(salary) from employees
group by DEPARTMENT_id


select *
from EMPLOYEES 
where salary in(select salary from employees where first_name = 'John')


select department_id, max(salary)

from employees
group by DEPARTMENT_id
having department_id is not null


select EMPLOYEE_id, first_name,salary, department_id
from employees
--월급이 서브쿼리에 값1개라도 매칭되면 모두 검출된다
where salary in(select max(salary)
				from employees
				group by DEPARTMENT_id
				having department_id is not null)	


--서브쿼리는 from절, select 구문 어디든지올 수 있음
--null이 생략된 부서번호와 그 부서에서 최대 월급을 받은 직원.
--이 구문이 from 절에 오면 이 값 자체가 table이 된다.
select max(salary), department_id
from employees
group by DEPARTMENT_id
having department_id is not null

--컬럼의 이름이 동일하므로 지정을 해줘야 한다.
select employee_id,first_name, e.salary, d.department_id
from employees e, (select department_id, max(salary) sal
					from employees
					group by department_id
					having department_id is not null) d
where e.department_id = d.department_id
and e.salary = d.sal
order by e.employee_id


--사번, 이름, 월급, 평균 월급, 차이, 부서번호, 부서명 출력
select EMPLOYEE_id, first_name, salary, 
		(select trunc(avg(salary)) from employees) as "avg", 
		salary- (select round(avg(salary))from employees) as "차이", 
		e.department_id, d.department_name
from employees e, departments d
where e.department_id = d.department


--any
--서브쿼리의 값과 비교값 중1개라도 매칭이 되면(true) 결과물로 출력
--in은 any로 변경 가능
select *
from EMPLOYEES 
where salary = any(select salary from EMPLOYEES where first_name = 'John')

--가장 작은 값보다 큰 값
select *
from EMPLOYEES 
where salary >= any(select salary from EMPLOYEES where first_name = 'John')

--가장 큰 값보다 작은 값
select *
from EMPLOYEES 
where salary <= any(select salary from EMPLOYEES where first_name = 'John')

--all 
--서브쿼리의 결과값과 비교값이 모두 true이어야 결과로 출력된다.

--최대값보다 큰 값만 true
select *
from EMPLOYEES 
where salary >= any(select salary from EMPLOYEES where first_name = 'John')

--최소값보다 작은 값만 true
select *
from EMPLOYEES 
where salary <= any(select salary from EMPLOYEES where first_name = 'John')


--다중 열 서브쿼리


select employee_id,first_name, e.salary, d.department_id
from employees e, (select department_id, max(salary) sal
					from employees
					group by department_id
					having department_id is not null) d
where e.department_id = d.department_id
and e.salary = d.sal
order by e.employee_id


select employee_id,first_name, salary, department_id
from employees
where (department_id,salary) in (select department_id, max(salary) as sal
					from employees
					group by department_id
					having department_id is not null)
order by e.employee_id




















































































