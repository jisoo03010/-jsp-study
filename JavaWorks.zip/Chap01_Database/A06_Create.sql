-- Create

--작성
create tableName(
	fieldName type constraintName constraint-종류 
	fieldName type default defaultValue 
)

--제약조건
--primary key -> 중복 값 대입 불가, 값을 반드시 입력해야 한다(NULL 상태안됨)
--not null  -> 값을 반드시 입력해야 한다.
--unique  -> 중복 값 대입 불가, NULL은 중복가능( 즉 NULL 입력가능)
--check   -> 조건에 만족한 값만 입력 가능
--foreign key -> 다른 테이블의 pk를 참조하는 값

--기본값 지정
--default 0 -> 데이터를 입력하지 않으면 기본 값으로 0이 입력된다.
--default sysdate -> 데이터를 입력하지 않으면 기본 값으로 현재시간이 입력된다.

--number(전체 자리수, 실수 자리수)
--정수, 실수타입모두 number로 정의.
--전체 자리수는 말 그대로 전체 자리수를 의미하며 실수자리수는
--전체 자리수에서 몇 자리를 실수로 쓸것인가를 결정
--number(10,2) -> 전체 10자리
--이중에서 8자리는 정수로 사용하고 2자리는 실수로 사용한다는 의미
--number(2,2) -> 전체 2자리 전체를 실수로 사용, 정수 입력
--varchar2(30) -> 가변문자. 영문30글자, 한글은 15글자 까지 입력 가능
-- 가변이라 1글자만 입력한 1byte로 사이즈가 줄어든다
--char(10) -> 고정문자열, 항상 10자리를 확보한다.
-- 즉 1글자를 입력해도 10byte는 용량을 잡는다.

create table dept(
	dept_id	number(3) primary key,
	dept_name varchar2(20) not null
)


create table emp(
	emp_id number(5,0) primary key,
	emp_pw varchar2(30)  not null,
	emp_name varchar2(30) not null,
	gender char(1) check(gender in ('m','f', 'e')),
	address varchar2(100),
	tel varchar2(13) unique,
	salary number(7) not null,
	regdate date default sysdate,
	dept_id number(3) references dept(dept_id)
)


select * from emp;
select * from dept;

--작성한 테이블 삭제
--기존의 테이블 삭제하지 마세요.
drop table emp;
drop table dept;

--테이블에 값 입력
--값 입력 명령
insert into tableName(columnName1, columnName2, ...)
values(정의한 순서대로 값을 입력한다...)

--또는
--이 방법은 테이블에 작성한 컬럼 순서대로 모은 값을 입력하는 경우 사용
insert into tableName
values(컬럼을 정의한 순서대로 값을 입력한다...)
--dept
insert into dept values(100, '영업부')
insert into dept values(101, '개발부')
--dept_id에 총모부입력
--dept_id는 타입이 number
--dept_name을 입력하지 않음 (not null 제약조건)
--insert  into(dept_name, dept_id) values('총모부') --error

--정상 실행.  into에 기술한 순서대로 값만 입력하면 됨

insert into(dept_name, dept_id) values('개발부', 101)

select * from dept

--emp
insert into emp
values(10,'abc123','abc','m', 'seoul' , '010-1234-5678',
	15000, '2021-01-25',100)
select * from emp

--전화번호가 unique(중복 불가). 동일한값으로 입력할 수없다. error
insert into emp
values(11,'abc123','abc','m', 'seoul' , '010-1234-5678',
	15000, '2021-01-25',100)
	
select * from emp

--리퍼런스 값은 그 테이블에 지정한 값만 있으면 입력된다. - ok

insert into emp
values(12,'abc123','abc','A', 'seoul' , '010-1234-5679',
	15000, '2021-01-25',100)
select * from emp

--gender에 'A'라는 값은 입력할 수 없다. -error
insert into emp
values(12,'abc123','abc','A', 'seoul' , '010-1234-5679',
	10000, '2021-01-25',101)
select * from emp

--error 주소를 입력하지 않음. 테이블명 emp 옆에 컬럼명을 생략한 경우 순차적으로 
--모든 값을 입력해야 한다.
insert into emp
values(12,'abc123','abc','f', 'Busan' , '010-1234-5680',
	15000, '2021-01-25',101)
select * from emp

--제약조건이 없는 경우 그 값으로 명시적으로 null을 입력할 수 있다. - ok
insert into emp
values(12,'abc123','abc','f', null , '010-1234-5680',
	15000, '2021-01-25',100)
select * from emp

--날짜의 타입이 다르다
insert into emp
values(13,'abc123','abc','f', null , '010-1234-5681',
	15000, '20210125',100)
--날짜의 타입이 다르다 -ok
	insert into emp
values(14,'abc123','abc','f', null , '010-1234-5682',
	15000, '2021*01*25',100)

--정식으로 넣으려면 to_date을 이용
insert into emp
values(15,'abc123','abc','f', null , '010-1234-5683',
	15000, '2021*01*25','YYYY-MM-DD',100)



--컬럼을 지정하는 경우
--입력한 필드 순서와 값의 순서가 맞아야한다.(물론 타입도 맞게 넣어야 함)
insert into emp(emp_id, emp_pw,emp_name,gender,address,tel,salary,regdate, dept_id)
values(16,'nolbu123','nolbu','m', 'YoungSan' , '010-1234-5684',
	18000, to_date('2021*05*25','YYYY-MM-DD'),101)

	
--컬럼을 지정하는 경우
--입력한 필드 순서와 값의 순서가 맞아야한다.(물론 타입도 맞게 넣어야 함)
insert into emp(emp_id, emp_pw,emp_name,salary, dept_id)
values(17,'hungbu123','hunglbu',19000,101)
	
--dept_id (foregin key) 도 null허용
insert into emp(emp_id, emp_pw,emp_name,salary)
values(18,'hungbu123','hungbu',18000)

--pk인 emp_id는 자동으로 1 더한값으로 입력되게 처리
insert into emp(emp_id, emp_pw,emp_name,salary)
values((select nvl(max(emp_id), 0) + 1 from emp),'hungbu123','hungbu',18000)
--update 수정
--where 절이 없으면 모든 데이터가 변경된다.
update tableName set = columnName = value, columnName= value, ..,
where PK = value

-- 이건 dept 테이블의  dept_name이 모두감사부로 변경된다.
update dept set dept_name ='감사부'
update dept set dept_name ='영업부'
where dept_id = 100;
update dept set dept_name ='총무부'
where dept_id = 101;

select * from emp
--emp

--다중열 변경, where절에서 매칭되는 값이 여러개면 해당하는 모든 row가 생긴다
update emp set emp_name = 'Unknown', salary =0,regdate =null
where emp_name = 'abc';

update emp set emp_name = '방자', salary =8000,regdate =sysdate
where emp_id = emp;
	
	
--delete 삭제
--where 절이 없으면 모든 컬럼이 삭제 된다.
delete from tableName
where PK = value
	
	
delete from emp 
	
select * from emp

rollback
	
--지정한 row만 삭제 한다. where조건이 여러줄이면 해당 row는 모두 삭제 된다.
delete from emp
where emp_id =10
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

