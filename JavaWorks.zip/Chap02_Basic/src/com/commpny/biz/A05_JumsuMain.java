package com.commpny.biz;

public class A05_JumsuMain {
	public static void main(String[] args) {
		A05_Jumsu nolbu = new A05_Jumsu();
		System.out.println(nolbu.kor);
		System.out.println(nolbu.name);
		nolbu.kor =90 ;
		nolbu.eng = 90;
		nolbu.total = nolbu.kor + nolbu.eng;
		nolbu.avg = nolbu.total /2;
		nolbu.name = "놀부";
		System.out.println(nolbu.name + "님의 총점은" +nolbu.total 
				+ "이고 평균은" + nolbu.avg + "입니다.");
		
		
		////////////////////////////////////////////
		A05_Jumsu hungbu = new A05_Jumsu();
		System.out.println(hungbu.kor);
		System.out.println(hungbu.name);
		hungbu.kor =90 ;
		hungbu.eng = 90;
		hungbu.total = hungbu.kor + hungbu.eng;
		hungbu.avg = hungbu.total /2;
		hungbu.name = "흥부";
		System.out.println(hungbu.name + "님의 총점은" +hungbu.total 
				+ "이고 평균은" + hungbu.avg + "입니다.");

	}
}
