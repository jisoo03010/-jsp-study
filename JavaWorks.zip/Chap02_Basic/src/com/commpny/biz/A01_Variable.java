package com.commpny.biz;

class Calc {
	int i =100;
	
}
public class A01_Variable {
	//나중에 테스트용으로만 사용한다.
	public static void main(String[] args) {
		
		//기본형 변수
		byte bt = 10;  //-128~ 127
		short sh = 10;   //+-32000
		
		 //-128~ 127 , 127 + 1 = -128, 127+2 = -127, 127+3 = -126
		int i = 129;      //+-20억
		
		
		long lg =10l;   // 그 외의 큰 정수 값
		
		float fl = 10.25f;  //소수점 7자리까지의 정확도
		double dou = 10.25;  //소수점 15자리까지의 정확도
		
		boolean check = true;  
		//int의 모든 물건을 byte의 조그만한 방에 옮길 수 없음	 - error
	    //byte bt1 = i;
		
		//업 캐스팅. 아무런 조건 없이 자동으로 이루어진다.
		//작은방 byte의 모든 물건을 큰 방을 옮길 수 있음 - ok
		//int i1 = bt; 
			
		//작은방으로 이사가려면 ㅇ떻게 해야 할까?
		//물건의 일부를 버리면 된다 -> 다운 캐스팅 (강제 캐스팅)
		
		//값 오브플로어(값넘침)이 발생하면 쓰래기 값이 들어간다.
		byte bt1 = (byte)i;
		System.out.println("bt1 => " + bt1);
		
		String[] str = {"a","b","c"};
		
		//만든 클래스는 다 type이다.
		Calc calc = new Calc();
		System.out.println(calc.i);
		
		// error .. fSystem.out.println(bt1);
		System.out.println(bt);
	}
}
