package com.commpny.biz;

public class A06_JumsuMain {
	public static void main(String[] args) {
		A05_Jumsu nolbu = new A05_Jumsu();
		A05_Jumsu hungbu = new A05_Jumsu();
		A05_Jumsu bangja = new A05_Jumsu();
		
		//배열은 하나의 타입만 대입 가능하다.
		A05_Jumsu[] students = {nolbu, hungbu};
		students[0].name = "놀부";
		students[0].kor = 100;
		students[0].eng = 30;
		//students[0].total = students[0].kor + students[0].eng;
		//students[0].avg = students[0].total /2 ;
		
		//System.out.println(students[0].name + "님의 총점은" +students[0].total 
		//		+ "이고 평균은" + students[0].avg + "입니다.");
		
		
		
		students[1].name = "흥부";
		students[1].kor = 70;
		students[1].eng = 60;
		//students[1].total = students[1].kor + students[1].eng;
		//students[1].avg = students[1].total /2 ;
		
		//System.out.println(students[1].name + "님의 총점은" +students[1].total 
		//		+ "이고 평균은" + students[1].avg + "입니다.");
		
		for (int i = 0; i < students.length; i++) {
			students[i].total = students[i].kor + students[i].eng;
			students[i].avg = students[i].total /2 ;
			
			System.out.println(students[i].name + "님의 총점은" +students[i].total 
					+ "이고 평균은" + students[i].avg + "입니다.");
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}
}
