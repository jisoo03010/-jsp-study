package com.commpny.biz;

//vm이 호출하는 메서드를 가지고 있는 클래스
public class A04_JumsuMain {
	
	static int i =10;
	int k =100;
	
	
	//이 메인은 메서드와 현재 클래스와 상관없는 독립적인 하나의 클래스 형태로 봐야 함.
	// JVM이 독립적으로 호출해서 실해오디는 메서든
	public static void main(String[] args) {
		
		System.out.println(i);
		
		
		A04_JumsuMain m = new A04_JumsuMain();
		System.out.println(m.k);
	}

}
