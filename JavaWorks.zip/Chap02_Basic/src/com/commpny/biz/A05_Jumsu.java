package com.commpny.biz;

//메모리에 이 구조를 찍어내는 원판
// 호텔로 따지면 각 객실인데 객실은 항상 청소가 되어있다.(초기화가 자동으로 된다)
// 숫자타입은 =>  0  또는 0.0으로
// 문자타입은 => null
//boolean => false
//객체 타입    => null
//char    => \u0000

public class A05_Jumsu {
	String name;
	 int kor;
	 int eng;
	 int total;
	 int avg;
	 int math;
	 
	 
}
