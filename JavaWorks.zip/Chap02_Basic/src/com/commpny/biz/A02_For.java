package com.commpny.biz;

public class A02_For {
	public static void main(String[] args) {
		// 3단 구구단 출력
		for(int i =1; i<10 ; i++ ) {
			System.out.println("3 *"  + i + " = " + (3 * i));
		}
	
	
	//구구단 2단부터9단 까지
	for(int i = 0 ; i < 10; i++) {
		for(int j = 1; j < 10; j++) {
			System.out.println(i +"*"  + j + " = " + (i * j));
		}
	}
	System.out.println("");
}
}