package com.commpny.biz;

public class A07_Jumsu {
		String name;
		 int kor;
		 int eng;
		 int total;
		 int avg;
		 
		 //현재 멤버변수를 초기화 할 메서드 정의
		 void setMember(String name, int kor, int eng) {
			 name = this.name;
			 kor = this.kor;
			 eng = this.eng;
			 
		 }
		 //생서자 메서드
		 //인스턴스를 생성할떄  자신의  멤버변수를 초기화할 목적으로 사용한다
		 //위의setMember와 동일한 역할
		 //문법 : 
		 //1.생성자 메서드는 리턴 타입을 기술하지 않는다.
		 //2. 생성자 메서드의 이름으 class의 이름과동일하게 않는다.
		 //3. 생성자 메서드를 작성하지않으면 JVM이 자동으로 기본 생성자 메서드를 만들어 준다.
		 //4. 작성자가생성자 메서드를 1개라도 만들면 JVM은 기본 생성자 메서드를 만들지 않는다.
		 
		 //기본 생성자 메소드
		 //사용자 쪽에서 호출하는 new A07_Jumsu()가 이 메서드를 호출하는 것이다.
		 A07_Jumsu(){
			 
		 }
		 //생성자 메서드도 메서드니까 매개변수를 받을 수 있따.
		 A07_Jumsu(String name, int kor, int eng){
			 name = this.name;
			 kor = this.kor;
			 eng = this.eng;
		 }
		 
		 
		 //사용하는 쪽에서 호출해서 처리할 로직을 구현해 제공한다.
		 //메서드 정의 방법
		 //[접근 제한자] 리턴타입 메서드명([매개변수, 매개변수...]){
		 //		메서드명이 호출되면 처리할 로직
		 //     ...
		 //}
		void onTotal(){
			if(this.kor ==0 || eng == 0) {
				System.out.println("값이 입력 되지 않았습니다");
			}else {
				this.total = this.kor + this.eng;
			}
			 total = kor + eng;
		 }
		//메서드의 매개변수는 값을 호출하는곳에서 전달 되었다는 가정하에 메서드를 작성한다.
		//왜? 이메서드를 호출할때 값을 넘겨주지 않으면 호출하는 곳에서 에러 발생
		
		
		void onAvg(int num) {
			avg = total / num;
		}
		void display() {
			System.out.println(name + "님의 총점은" +total 
					+ "이고 평균은" + avg + "입니다.");
		}
}
