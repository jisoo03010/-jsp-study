package com.commpny.biz;

//void main(String[] args)가 없는 클래스는 불려져서 사용될 목적으로
//작성하는 클래서. 클래스의 이름이 타입이다.
//package = > 현재 클래스가 속해 있는 파일 경로
//import  = > 현재 클래스가 속해 있는 폴더 이외의 폴더에 있는 클래스를 불러오는 경우에 사용
//BUildIn(이미 만들어 제공되는 클래스)중 java.lang package 이외의 클래스를 불러오는 경우
public class A04_JumsuClass {
	//변수 선언. = > 멤버변수
	//메서드.   = > 멤버 메서드
	
	
	
}
