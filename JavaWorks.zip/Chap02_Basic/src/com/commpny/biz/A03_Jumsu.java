package com.commpny.biz;

public class A03_Jumsu {
	public static void main(String[] args) {
		String nolBUName = "놀부";
		int kor = 80;
		int eng = 70;
		int total = kor + eng;
		double avg = total / 2.0;
		
		System.out.println(nolBUName +"님의 총점은" + total + "이고 평균은"+ avg + "입니다");
		
		
		//java의 배열은 조자 메서트(명령)이 없다
		//한 가지의 타입만 가질 수 있다.
		//크기를 한 번 선언하면 변경 할 수 없다.
		
		String hungBUName = "흥부";
		int[] hungBuJumsu = {70,90,0,0};
		hungBuJumsu[2] = hungBuJumsu[0] + hungBuJumsu[1];
		hungBuJumsu[3] = hungBuJumsu[2] / 2;
		System.out.println(hungBUName +"님의 총점은" + hungBuJumsu[2] + "이고 평균은"+ hungBuJumsu[3] + "입니다");
		
		//한 학급 정보를 하나의 변수로 묶자
		int[][] jumsu = {{90,80,0,0},{80,50,0,0}};
		String[] name = {"NolBU" , "HungBU"};
		
		for (int i = 0; i < name.length; i++) {
			System.out.println(name[i] + "의 점수 입니다.");
			
			jumsu[i][2] = jumsu[i][0] + jumsu[i][1] ;
			jumsu[i][3] = jumsu[1][2] /2 ;
			
			System.out.println("총점은" + jumsu[i][2] + "이고 평균은" + jumsu[i][3] + "입니다");
		}
	}
}
