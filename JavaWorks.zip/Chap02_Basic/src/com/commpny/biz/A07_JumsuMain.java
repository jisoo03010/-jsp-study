package com.commpny.biz;

public class A07_JumsuMain {

	public static void main(String[] args) {
		A07_Jumsu nolbu =new A07_Jumsu("놀부", 100, 90);
		//nolbu.setMember("놀부", 100, 90);

		//인스턴스의 코기값 세팅을 위함 메서드호출
		//이 기능을 이미 작정해 놓은 메서드가 생성자 메서드이다.
		nolbu.onTotal();
		nolbu.onAvg(2);
		nolbu.display();
		//nolbu.name = "놀부";
		//nolbu.kor = 100;
		//nolbu.eng = 90;
		A07_Jumsu bangja =new A07_Jumsu("방자", 70, 60);
		//nolbu.setMember("방자", 70, 60);
		//nolbu.name = "방자";
		//nolbu.kor = 70;
		//nolbu.eng = 60;
		nolbu.onTotal();
		nolbu.onAvg(3);
		nolbu.display();

	}

}
