/**
 * 
 */


function check(){
	var form = document.forms['tbl_form'];
	
	if(!form['userid'].value){
		alrter("아이디는 4자~12자 이내로 입력가능합니다.");
		form.userid.focus();
		return false;
	}else if(!form['usernm'].value){
		alrter("이름 미입력");
		form.usernm.focus();
		return false;
	}else if(!form['passwd'].value){
		alrter("비밀번호 미입력");
		form.usernm.focus();
		return false;
	}else if(!form['gender'].value){
		alrter("비밀번호 미입력");
		form.usernm.focus();
		return false;
	}else if(!form['address'].value){
		alrter("비밀번호 미입력");
		form.usernm.focus();
		return false;
	}else if(!form['jobcd'].value){
		alrter("비밀번호 미입력");
		form.usernm.focus();
		return false;
	}
	return true;
}
