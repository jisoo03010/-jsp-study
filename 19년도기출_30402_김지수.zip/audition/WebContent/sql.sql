create table TBL_ARTIST_201905(
	artist_id char(4) not null primary key,
	artist_name varchar2(20),
	artist_birth char(8),
	artist_gender char(1),
	talent char(1),
	agency varchar2(30)
)
insert into TBL_ARTIST_201905 values('A001', '김스타', '19970101', 'F', '1', 'A엔터테인먼트');
insert into TBL_ARTIST_201905 values('A002', '조스타', '19980201', 'M', '2', 'B엔터테인먼트');
insert into TBL_ARTIST_201905 values('A003', '왕스타', '19900301', 'M', '3', 'C엔터테인먼트');
insert into TBL_ARTIST_201905 values('A004', '정스타', '20000401', 'M', '1', 'D엔터테인먼트');
insert into TBL_ARTIST_201905 values('A005', '홍스타', '20010501', 'F', '2', 'E엔터테인먼트');

create table TBL_MENTO_201905( 
	mento_id char(4) not null primary key,
	mento_name varchar2(20)
	
)

insert into TBL_MENTO_201905 values('J001', '황멘토');
insert into TBL_MENTO_201905 values('J002', '박멘토');
insert into TBL_MENTO_201905 values('J003', '장멘토');

create table TBL_POINT_201905( 
	serial_no varchar2(8) not null primary key,
	artist_id char(4),
	mento_id char(4),
	point number(3)
)


insert into TBL_POINT_201905 values('20190001', 'A001', 'J001', 78);
insert into TBL_POINT_201905 values('20190002', 'A001', 'J002', 76);
insert into TBL_POINT_201905 values('20190003', 'A001', 'J003', 70);
insert into TBL_POINT_201905 values('20190004', 'A002', 'J001', 80);
insert into TBL_POINT_201905 values('20190005', 'A002', 'J002', 72);
insert into TBL_POINT_201905 values('20190006', 'A002', 'J003', 78);
insert into TBL_POINT_201905 values('20190007', 'A003', 'J001', 90);
insert into TBL_POINT_201905 values('20190008', 'A003', 'J002', 92);
insert into TBL_POINT_201905 values('20190009', 'A003', 'J003', 88);
insert into TBL_POINT_201905 values('20190010', 'A004', 'J001', 96);
insert into TBL_POINT_201905 values('20190011', 'A004', 'J002', 90);
insert into TBL_POINT_201905 values('20190012', 'A004', 'J003', 98);
insert into TBL_POINT_201905 values('20190013', 'A005', 'J001', 88);
insert into TBL_POINT_201905 values('20190014', 'A005', 'J002', 86);
insert into TBL_POINT_201905 values('20190015', 'A005', 'J003', 86);

select * from TBL_ARTIST_201905

select * from TBL_POINT_201905

select * from TBL_ARTIST_20190



SELECT * FROM TBL_ARTIST_201905


insert into  TBL_ARTIST_201905 values(?, ?, ?, ?, ?, ?);
