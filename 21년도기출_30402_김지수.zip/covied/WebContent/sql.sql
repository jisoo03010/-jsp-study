select * from tbl_jumin_201808
select * from TBL_HOSP_202108
select * from TBL_VACCRESV_202108

drop table TBL_VACCRESV_202108


create table tbl_jumin_201808(
	jumin char(14) not null primary key,
	pname varchar2(16),
	tel varchar2(13),
	address varchar2(10)
)

insert into tbl_jumin_201808 values('700101-1000001', '���ֹ�', '010-1234-0001', '����' );
insert into tbl_jumin_201808 values('700101-1000002', '���ֹ�', '010-1234-0002', '����' );
insert into tbl_jumin_201808 values('700101-1000003', '���ֹ�', '010-1234-0003', '����' );
insert into tbl_jumin_201808 values('700101-1000004', '���ֹ�', '010-1234-0004', '����' );
insert into tbl_jumin_201808 values('700101-1000005', 'ȫ�ֹ�', '010-1234-0005', '����' );
insert into tbl_jumin_201808 values('700101-1000006', '���ֹ�', '010-1234-0006', '�뱸' );
insert into tbl_jumin_201808 values('700101-1000007', 'Ȳ�ֹ�', '010-1234-0007', '�뱸' );
insert into tbl_jumin_201808 values('700101-1000008', '���ֹ�', '010-1234-0008', '����' );
insert into tbl_jumin_201808 values('700101-1000009', '���ֹ�', '010-1234-0009', '����' );
insert into tbl_jumin_201808 values('700101-1000010', '���ֹ�', '010-1234-0010', '����' );


create table TBL_HOSP_202108( 
	hospcode char(4) not null primary key,
	hospname varchar2(10),
	hosptel varchar2(10),
	hospaddr varchar2(10)
)

insert into TBL_HOSP_202108 values('H001', '��-����', '1588-0001', '����');
insert into TBL_HOSP_202108 values('H002', '��-����', '1588-0002', '����');
insert into TBL_HOSP_202108 values('H003', '��-����', '1588-0003', '�뱸');
insert into TBL_HOSP_202108 values('H004', '��-����', '1588-0004', '����');


create table TBL_VACCRESV_202108( 
	resvno char(8) not null primary key,
	jumin char(14),
	vcode char(4),
	hospcode char(4),
	resvdate char(8),
	resvtime char(4)
)



insert into TBL_VACCRESV_202108 values('20210001', '700101-1000001' ,'V001', 'H001' ,'20210901', '0920');
insert into TBL_VACCRESV_202108 values('20210002', '700101-1000002' ,'V001', 'H002' ,'20210901', '1030');
insert into TBL_VACCRESV_202108 values('20210003', '700101-1000003' ,'V002', 'H003' ,'20210902', '1130');
insert into TBL_VACCRESV_202108 values('20210004', '700101-1000004' ,'V002', 'H001' ,'20210902', '1230');
insert into TBL_VACCRESV_202108 values('20210005', '700101-1000005' ,'V002', 'H002' ,'20210902', '1330');
insert into TBL_VACCRESV_202108 values('20210006', '700101-1000006' ,'V001', 'H003' ,'20210903', '1430');
insert into TBL_VACCRESV_202108 values('20210007', '700101-1000007' ,'V001', 'H001' ,'20210903', '1530');
insert into TBL_VACCRESV_202108 values('20210008', '700101-1000008' ,'V001', 'H002' ,'20210903', '1630');
insert into TBL_VACCRESV_202108 values('20210009', '700101-1000009' ,'V001', 'H003' ,'20210901', '1730');
insert into TBL_VACCRESV_202108 values('20210010', '700101-1000010' ,'V001', 'H001' ,'20210901', '1830');



select * from TBL_VACCRESV_202108




SELECT * FROM  TBL_VACCRESV_202108 WHERE resvno IN (?);






select tv.resvno ,tj.pname, tj.jumin, decode(substr(tj.jumin, 8, 1) , '1', '����', '2', '����'), tj.tel,
		tv.resvdate, tv.resvtime, th.hospname, th.hosptel, th.hospaddr, tv.vcode 
from tbl_jumin_201808 tj, TBL_VACCRESV_202108 tv , TBL_HOSP_202108 th
where tv.jumin = tj.jumin and tv.hospcode = th.hospcode and tv.resvno = '20210005'


select *
from tbl_jumin_201808 tj, TBL_VACCRESV_202108 tv , TBL_HOSP_202108 th




--������ �����Ǽ� ��� ������

--�����ڵ�, ������, �����Ǽ�
select * from TBL_HOSP_202108 natural join TBL_VACCRESV_202108

select hospcode, hospname
from TBL_HOSP_202108 natural join TBL_VACCRESV_202108

--10��
select hospcode, hospname ,count(hospname) ,(select count(hospname) 
from TBL_HOSP_202108 natural join TBL_VACCRESV_202108
where hospcode = hospcode)
from TBL_HOSP_202108 natural join TBL_VACCRESV_202108
where hospcode = hospcode
group by hospcode, hospname
order by hospname





SELECT  hospcode ,DECODE(GROUPING(hospname), 1, '�� ����', hospname) AS hospname  ,count(hospname)
from TBL_HOSP_202108 natural join TBL_VACCRESV_202108
where hospcode = hospcode
GROUP BY ROLLUP( hospcode, hospname)
HAVING GROUPING_ID(hospcode, hospname) IN (0, 3)





